import os
import re
import io
import math
import numpy as np
import requests

from fastapi import FastAPI
from pydantic import BaseModel
from databricks.sdk import WorkspaceClient
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------

CHAT_MODEL = os.environ.get("CHAT_MODEL", "databricks-llama-4-maverick")
WAREHOUSE_ID = os.environ.get("WAREHOUSE_ID", "4bddb0c7d84eee0b")
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "databricks-gte-large-en-v1.5")
RAG_FOLDER = os.environ.get("RAG_FOLDER", "/Project/RAG")
RAG_CHUNK_SIZE = int(os.environ.get("RAG_CHUNK_SIZE", "1000"))
RAG_CHUNK_OVERLAP = int(os.environ.get("RAG_CHUNK_OVERLAP", "200"))
RAG_TOP_K = int(os.environ.get("RAG_TOP_K", "5"))

# ---------------------------------------------------------
# FastAPI
# ---------------------------------------------------------

app = FastAPI()

app.mount(
    "/static",
    StaticFiles(directory="static"),
    name="static",
)

# ---------------------------------------------------------
# Databricks client
# ---------------------------------------------------------

w = WorkspaceClient()

auth_headers = w.config.authenticate()
access_token = auth_headers["Authorization"].replace("Bearer ", "", 1)
workspace_host = w.config.host
serving_endpoint = workspace_host.rstrip("/") + "/serving-endpoints"

print(f"Workspace host: {workspace_host}")
print(f"Chat model: {CHAT_MODEL}")
print(f"Warehouse ID: {WAREHOUSE_ID}")
print(f"Embedding model: {EMBEDDING_MODEL}")
print(f"RAG folder: {RAG_FOLDER}")

# ---------------------------------------------------------
# RAG: Load and chunk PDF documents
# ---------------------------------------------------------

rag_chunks = []      # list of {"text": str, "source": str, "page": int}
rag_embeddings = []   # list of np.ndarray

def load_rag_documents():
    """Download PDFs from the workspace RAG folder, extract text, and chunk."""
    chunks = []
    try:
        entries = list(w.workspace.list(RAG_FOLDER))
    except Exception as e:
        print(f"  RAG: Could not list folder {RAG_FOLDER}: {e}")
        return chunks

    pdf_files = [e for e in entries if e.path.lower().endswith(".pdf")]
    print(f"  RAG: Found {len(pdf_files)} PDF file(s) in {RAG_FOLDER}")

    for entry in pdf_files:
        path = entry.path
        source_name = os.path.basename(path)
        print(f"  RAG: Loading {source_name} ...")
        try:
            import PyPDF2
            data = w.workspace.download(path)
            content = data.read() if hasattr(data, "read") else data
            buf = io.BytesIO(content)
            reader = PyPDF2.PdfReader(buf)
            for page_num, page in enumerate(reader.pages, start=1):
                text = page.extract_text() or ""
                text = text.strip()
                if not text:
                    continue
                # Split into overlapping chunks
                for chunk_text in split_text(text, RAG_CHUNK_SIZE, RAG_CHUNK_OVERLAP):
                    chunks.append({
                        "text": chunk_text,
                        "source": source_name,
                        "page": page_num,
                    })
            print(f"    {source_name}: {len(reader.pages)} page(s) parsed")
        except Exception as e:
            print(f"    ERROR loading {source_name}: {e}")

    print(f"  RAG: Total chunks: {len(chunks)}")
    return chunks

def split_text(text: str, chunk_size: int, overlap: int) -> list[str]:
    """Split text into overlapping chunks of approximately chunk_size characters."""
    if len(text) <= chunk_size:
        return [text]
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        # Try to break at a sentence or word boundary
        if end < len(text):
            last_period = chunk.rfind(".")
            last_newline = chunk.rfind("\n")
            break_point = max(last_period, last_newline)
            if break_point > chunk_size // 2:
                end = start + break_point + 1
                chunk = text[start:end]
        chunks.append(chunk.strip())
        start = end - overlap
    return [c for c in chunks if c]

# ---------------------------------------------------------
# RAG: Embeddings
# ---------------------------------------------------------

import time as _time

def generate_embeddings(texts: list[str]) -> list[list[float]]:
    """Call the Databricks Foundation Model embedding endpoint for a batch of texts."""
    if not texts:
        return []
    max_retries = 5
    for attempt in range(max_retries):
        resp = requests.post(
            f"{serving_endpoint}/{EMBEDDING_MODEL}/invocations",
            headers={"Authorization": f"Bearer {access_token}"},
            json={"input": texts},
            timeout=60,
        )
        if resp.status_code == 429 and attempt < max_retries - 1:
            wait = 2 ** attempt
            print(f"  RAG: Embedding rate limited, retrying in {wait}s (attempt {attempt + 1}/{max_retries})")
            _time.sleep(wait)
            continue
        resp.raise_for_status()
        data = resp.json()
        # OpenAI-style response: {"data": [{"embedding": [...], ...}, ...]}
        if "data" in data and isinstance(data["data"], list) and data["data"] and "embedding" in data["data"][0]:
            return [item["embedding"] for item in data["data"]]
        # Legacy response format
        elif "predictions" in data:
            return [p["data"] if isinstance(p, dict) and "data" in p else p for p in data["predictions"]]
        else:
            raise ValueError(f"Unexpected embedding response format: {list(data.keys())}")
    raise RuntimeError("Embedding request failed after max retries")

def build_rag_index():
    """Load documents, chunk them, and generate embeddings."""
    global rag_chunks, rag_embeddings
    rag_chunks = load_rag_documents()
    if not rag_chunks:
        print("  RAG: No chunks loaded — RAG will be unavailable.")
        return
    # Generate embeddings in small batches to avoid rate limits
    batch_size = 10
    all_embeddings = []
    texts = [c["text"] for c in rag_chunks]
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        embs = generate_embeddings(batch)
        all_embeddings.extend(embs)
        print(f"  RAG: Embedded {min(i + batch_size, len(texts))}/{len(texts)} chunks")
        if i + batch_size < len(texts):
            _time.sleep(1)
    rag_embeddings = [np.array(e, dtype=np.float32) for e in all_embeddings]
    print(f"  RAG: Index ready ({len(rag_embeddings)} embeddings)")

def retrieve_rag_context(question: str, top_k: int = RAG_TOP_K) -> list[dict]:
    """Retrieve the top-k most relevant chunks for the question via cosine similarity."""
    if not rag_chunks or not rag_embeddings:
        return []
    q_emb = np.array(generate_embeddings([question])[0], dtype=np.float32)
    q_norm = np.linalg.norm(q_emb)
    if q_norm == 0:
        return []
    scores = []
    for i, emb in enumerate(rag_embeddings):
        emb_norm = np.linalg.norm(emb)
        if emb_norm == 0:
            scores.append(0.0)
        else:
            sim = float(np.dot(q_emb, emb) / (q_norm * emb_norm))
            scores.append((sim, i))
    scores.sort(key=lambda x: x[0], reverse=True)
    results = []
    for sim, idx in scores[:top_k]:
        chunk = rag_chunks[idx].copy()
        chunk["score"] = sim
        results.append(chunk)
    return results

# ---------------------------------------------------------
# Database schema description
# ---------------------------------------------------------

SCHEMA_DESCRIPTION = """
DATABASE SCHEMA — workspace.project_db

Table: workspace.project_db.assets
  Columns: Asset_ID (string), Asset_Name (string), Asset_Type (string),
  Asset_Category (string), Description (string), Manufacturer (string),
  Model (string), Serial_Number (string), Asset_Tag (string),
  Hostname (string), IP_Address (string), MAC_Address (string),
  Site (string), Area (string), Unit (string), Cabinet (string),
  Rack (string), Zone (string), Purdue_Level (string),
  Security_Zone (string), Network_Segment (string), VLAN (bigint),
  Switch (string), Switch_Port (string), Owner (string),
  System_Owner (string), OT_Security_Owner (string), Vendor (string),
  Integrator (string), Criticality (string), Safety_Criticality (string),
  Business_Criticality (string), Operational_Criticality (string),
  OS (string), OS_Version (string), Firmware (string),
  Firmware_Version (string), Application (string),
  Application_Version (string), PLC_Runtime (string),
  Patch_Level (string), EOL_Status (string), Support_Status (string),
  OT_Protocols (string), Open_Ports (string), Communication_Partners (string),
  Remote_Access (string), Remote_Access_Method (string),
  Authentication (string), MFA (string), EDR_AV (string),
  Logging (string), SIEM (string), Network_Monitoring (string),
  Backup_Status (string), Last_Backup (string), Last_Restore_Test (string),
  Configuration_Backup (string), PLC_Logic_Version (string),
  Last_Configuration_Change (string), Last_Maintenance (string),
  Last_Security_Assessment (string), Last_Vulnerability_Assessment (string),
  CVE_Count (bigint), Highest_CVSS (double), Compensating_Controls (string),
  Risk_Rating (string), Risk_Assessment_Date (string), RTO (string),
  RPO (string), Commission_Date (string), EOL_Date (string),
  Replacement_Plan (string), Lifecycle_Status (string),
  Discovery_Source (string), First_Discovered (string),
  Last_Verified (string), Inventory_Confidence (string)

Table: workspace.project_db.network_interfaces
  Columns: Asset_ID (string, FK->assets.Asset_ID), Interface (string),
  IP_Address (string), MAC_Address (string), VLAN (bigint),
  Switch (string), Switch_Port (string), Subnet (string),
  Assignment (string), Security_Zone (string)

Table: workspace.project_db.communication_flows
  Columns: Source_Asset (string, FK->assets.Asset_ID),
  Destination_Asset (string, FK->assets.Asset_ID), Protocol (string),
  Port (string), Direction (string), Purpose (string),
  Business_Necessity (string)

Table: workspace.project_db.software_firmware
  Columns: Asset_ID (string, FK->assets.Asset_ID), Platform (string),
  Platform_Version (string), Software (string), Software_Version (string),
  Purpose (string)

Table: workspace.project_db.vulnerabilities
  Columns: Asset_ID (string, FK->assets.Asset_ID),
  Vulnerability_ID (string), Severity (string), CVSS (double),
  Status (string), Compensating_Control (string), Target_Date (string)

Table: workspace.project_db.relationships
  Columns: Source_Asset (string, FK->assets.Asset_ID),
  Target_Asset (string, FK->assets.Asset_ID), Relationship (string)

Table: workspace.project_db.readme
  Columns: Item (string), Value (string)

JOIN KEYS:
  network_interfaces.Asset_ID = assets.Asset_ID
  software_firmware.Asset_ID = assets.Asset_ID
  vulnerabilities.Asset_ID = assets.Asset_ID
  communication_flows.Source_Asset = assets.Asset_ID
  communication_flows.Destination_Asset = assets.Asset_ID
  relationships.Source_Asset = assets.Asset_ID
  relationships.Target_Asset = assets.Asset_ID
"""

SYSTEM_PROMPT = """You are an expert SQL assistant for an OT (Operational Technology) cybersecurity asset inventory database in Databricks Unity Catalog.

Your job: convert natural language questions into a single valid Databricks SQL query.

CRITICAL RULES:
1. Always use FULLY QUALIFIED table names: workspace.project_db.<table_name>
2. Return ONLY the SQL query — no markdown, no backticks, no explanation, no semicolons.
3. Asset_ID is the unique identifier for assets (e.g., 'PLC-001', 'SCADA-001', 'DCS-001', 'HMI-001').
   When a user says "asset PLC-001", filter on Asset_ID = 'PLC-001', NOT Asset_Name.
4. CVSS score is in the vulnerabilities table as column CVSS (double).
   Highest_CVSS in the assets table is the max CVSS per asset.
   When a user asks about "CVE risk score higher than 5", filter on v.CVSS > 5.
5. Use JOIN when the question spans multiple tables.
6. Select meaningful columns that answer the question — not SELECT *.
7. If the question cannot be answered from the available tables, return exactly: CANNOT_ANSWER

""" + SCHEMA_DESCRIPTION + """

EXAMPLE:
Question: "Give me all vulnerabilities for asset PLC-001 with a CVE risk score higher than 5"
SQL: SELECT a.Asset_ID, a.Asset_Name, v.Vulnerability_ID, v.Severity, v.CVSS, v.Status, v.Compensating_Control, v.Target_Date FROM workspace.project_db.assets a JOIN workspace.project_db.vulnerabilities v ON a.Asset_ID = v.Asset_ID WHERE a.Asset_ID = 'PLC-001' AND v.CVSS > 5
"""


ANSWER_SYSTEM_PROMPT = """You are the OT Asset Inventory Assistant, an expert in OT cybersecurity.
You are given a user's question, the SQL query that was generated, and the query results.
Your job is to provide a clear, concise natural language answer based on the data.

Rules:
1. Answer the user's question directly using the data from the query results.
2. If the results are empty, say so and explain what was searched for.
3. Be specific: mention asset names, IDs, counts, scores, etc. from the data.
4. If the user asks "how many", give the exact number.
5. If the user asks about the "highest" or "most", identify the specific item and its value.
6. Keep your answer concise but informative - 2-4 sentences typically.
7. Do not mention SQL or the query in your answer unless the user specifically asks about it.
"""


# ---------------------------------------------------------
# RAG: Classification and answer generation
# ---------------------------------------------------------

CLASSIFY_PROMPT = """You are a routing assistant for an OT cybersecurity asset inventory system.
Given a user question, classify it into one of three categories:

- DATABASE: The question asks about specific assets, vulnerabilities, network interfaces,
  communication flows, software/firmware records, or relationships that would be found
  in a database. Examples: "How many PLCs are there?", "List vulnerabilities for PLC-001",
  "Show all assets in Zone 2".
- DOCUMENTS: The question asks about procedures, policies, guidelines, standards, or
  processes for OT asset management. Examples: "What is the procedure for registering
  a new asset?", "How should network interfaces be configured?", "What is the
  vulnerability management process?".
- BOTH: The question requires information from both the database and the documents.
  Examples: "Which assets don't follow the firmware update procedure?",
  "Are there any assets that violate the network interface procedure?".

Respond with EXACTLY ONE WORD: DATABASE, DOCUMENTS, or BOTH.
"""

RAG_SYSTEM_PROMPT = """You are the OT Asset Inventory Assistant, an expert in OT cybersecurity.
You are given a user's question and relevant excerpts from OT asset management procedure documents.
Your job is to provide a clear, concise natural language answer based on the document excerpts.

Rules:
1. Answer the user's question directly using the information from the document excerpts.
2. If the excerpts do not contain enough information to answer, say so clearly.
3. Be specific: mention procedure names, step numbers, requirements, and details from the documents.
4. Cite the source document name for key claims (e.g., "According to the Vulnerabilities_Procedure...").
5. Keep your answer concise but informative — 2-4 sentences typically.
6. Do not make up information that is not in the provided excerpts.
"""

def classify_question(question: str) -> str:
    """Classify the question as DATABASE, DOCUMENTS, or BOTH using the LLM."""
    resp = requests.post(
        f"{serving_endpoint}/{CHAT_MODEL}/invocations",
        headers={"Authorization": f"Bearer {access_token}"},
        json={
            "messages": [
                {"role": "system", "content": CLASSIFY_PROMPT},
                {"role": "user", "content": question},
            ],
            "max_tokens": 10,
        },
        timeout=15,
    )
    resp.raise_for_status()
    result = resp.json()["choices"][0]["message"]["content"].strip().upper()
    # Normalize to valid categories
    for category in ("DATABASE", "DOCUMENTS", "BOTH"):
        if category in result:
            return category
    return "DATABASE"  # default to SQL path

def answer_from_documents(question: str, context_chunks: list[dict]) -> str:
    """Generate an answer from retrieved RAG document chunks."""
    context_parts = []
    for i, chunk in enumerate(context_chunks, start=1):
        context_parts.append(
            f"[Excerpt {i} — Source: {chunk['source']}, Page: {chunk['page']}]"
            + "\n" + chunk['text']
        )
    context_str = "\n\n".join(context_parts)

    prompt = (
        f"User question: {question}\n\n"
        f"Document excerpts:\n{context_str}\n\n"
        f"Please provide a natural language answer to the user's question based on these excerpts."
    )

    resp = requests.post(
        f"{serving_endpoint}/{CHAT_MODEL}/invocations",
        headers={"Authorization": f"Bearer {access_token}"},
        json={
            "messages": [
                {"role": "system", "content": RAG_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "max_tokens": 1000,
        },
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"].strip()

# Build the RAG index at startup
print("\n--- Building RAG index ---")
try:
    build_rag_index()
except Exception as e:
    print(f"  RAG index build failed: {e}")
print("--- RAG index build complete ---\n")


# ---------------------------------------------------------
# Text-to-SQL
# ---------------------------------------------------------

def generate_sql(question: str) -> str:
    resp = requests.post(
        f"{serving_endpoint}/{CHAT_MODEL}/invocations",
        headers={"Authorization": f"Bearer {access_token}"},
        json={
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Convert this question to SQL:\n{question}"},
            ],
            "max_tokens": 1000,
        },
        timeout=30,
    )
    resp.raise_for_status()
    sql = resp.json()["choices"][0]["message"]["content"].strip()

    # Clean up markdown if the LLM added it
    sql = re.sub(r"^```sql\s*", "", sql)
    sql = re.sub(r"^```\s*", "", sql)
    sql = re.sub(r"\s*```$", "", sql)
    sql = sql.strip().rstrip(";")

    return sql


# ---------------------------------------------------------
# Execute SQL
# ---------------------------------------------------------

def execute_sql(sql: str):
    result = w.statement_execution.execute_statement(
        warehouse_id=WAREHOUSE_ID,
        statement=sql,
        wait_timeout="50s",
    )

    columns = []
    rows = []

    state = result.status.state if result.status else "unknown"
    print(f"  SQL state: {state}")

    if result.manifest and result.manifest.schema:
        columns = [c.name for c in result.manifest.schema.columns]

    if result.result and result.result.data_array:
        for row in result.result.data_array:
            rows.append(list(row) if row else [])

    print(f"  Columns: {columns}")
    print(f"  Row count: {len(rows)}")
    if rows:
        print(f"  First row: {rows[0]}")

    return columns, rows


# ---------------------------------------------------------
# Generate natural language answer
# ---------------------------------------------------------

def generate_answer(question: str, sql: str, columns: list, rows: list) -> str:
    if not rows:
        data_str = "No rows returned (empty result set)."
    else:
        header = " | ".join(columns)
        separator = "-+-".join(["-" * len(c) for c in columns])
        data_lines = [header, separator]
        for row in rows[:50]:
            data_lines.append(" | ".join([str(v) if v is not None else "NULL" for v in row]))
        if len(rows) > 50:
            data_lines.append(f"... ({len(rows)} total rows, showing first 50)")
        data_str = "\n".join(data_lines)

    prompt = (
        f"User question: {question}\n\n"
        f"SQL query executed:\n{sql}\n\n"
        f"Query results ({len(rows)} rows):\n{data_str}\n\n"
        f"Please provide a natural language answer to the user's question based on these results."
    )

    resp = requests.post(
        f"{serving_endpoint}/{CHAT_MODEL}/invocations",
        headers={"Authorization": f"Bearer {access_token}"},
        json={
            "messages": [
                {"role": "system", "content": ANSWER_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "max_tokens": 1000,
        },
        timeout=30,
    )
    resp.raise_for_status()
    answer = resp.json()["choices"][0]["message"]["content"].strip()
    return answer


# ---------------------------------------------------------
# Request model
# ---------------------------------------------------------

class AskRequest(BaseModel):
    question: str


# ---------------------------------------------------------
# API endpoints
# ---------------------------------------------------------

@app.get("/")
def home():
    return FileResponse("static/index.html")


@app.post("/api/ask")
def ask(request: AskRequest):
    print(f"\n=== QUESTION: {request.question} ===")

    # Classify the question: DATABASE, DOCUMENTS, or BOTH
    try:
        category = classify_question(request.question)
        print(f"  Classification: {category}")
    except Exception as e:
        print(f"  Classification error: {e}")
        category = "DATABASE"

    # --- DOCUMENTS path: answer from RAG document retrieval ---
    if category == "DOCUMENTS":
        try:
            chunks = retrieve_rag_context(request.question)
            if not chunks:
                return {
                    "question": request.question,
                    "sql": "",
                    "answer": "No relevant documents were found to answer this question.",
                    "status": "error",
                    "source": "documents",
                    "sources": [],
                    "columns": [],
                    "rows": [],
                }
            answer = answer_from_documents(request.question, chunks)
            sources = sorted(set(c["source"] for c in chunks))
            return {
                "question": request.question,
                "sql": "",
                "answer": answer,
                "status": "ok",
                "source": "documents",
                "sources": sources,
                "columns": [],
                "rows": [],
            }
        except Exception as e:
            return {
                "question": request.question,
                "sql": "",
                "answer": f"Error retrieving document information: {str(e)}",
                "status": "error",
                "source": "documents",
                "sources": [],
                "columns": [],
                "rows": [],
            }

    # --- BOTH path: combine database results with document context ---
    if category == "BOTH":
        sql, columns, rows, sql_answer = "", [], [], ""
        try:
            sql = generate_sql(request.question)
            print(f"  Generated SQL: {sql}")
            if sql != "CANNOT_ANSWER":
                columns, rows = execute_sql(sql)
                sql_answer = generate_answer(request.question, sql, columns, rows)
        except Exception as e:
            print(f"  SQL path error in BOTH: {e}")

        doc_answer, doc_sources = "", []
        try:
            chunks = retrieve_rag_context(request.question)
            if chunks:
                doc_answer = answer_from_documents(request.question, chunks)
                doc_sources = sorted(set(c["source"] for c in chunks))
        except Exception as e:
            print(f"  RAG path error in BOTH: {e}")

        combined = []
        if sql_answer:
            combined.append(f"Database findings:\n{sql_answer}")
        if doc_answer:
            combined.append(f"Document guidance:\n{doc_answer}")
        if not combined:
            combined.append("No relevant information was found in the database or documents.")

        return {
            "question": request.question,
            "sql": sql,
            "answer": "\n\n".join(combined),
            "status": "ok",
            "source": "both",
            "sources": doc_sources,
            "columns": columns,
            "rows": rows,
        }

    # --- DATABASE path (default) ---
    try:
        sql = generate_sql(request.question)
        print(f"  Generated SQL: {sql}")
    except Exception as e:
        print(f"  SQL generation error: {e}")
        return {
            "question": request.question,
            "sql": "",
            "answer": f"Failed to generate SQL: {str(e)}",
            "status": "error",
            "source": "database",
            "sources": [],
            "columns": [],
            "rows": [],
        }

    if sql == "CANNOT_ANSWER":
        return {
            "question": request.question,
            "sql": "",
            "answer": "I cannot answer this question from the available database tables.",
            "status": "error",
            "source": "database",
            "sources": [],
            "columns": [],
            "rows": [],
        }

    try:
        columns, rows = execute_sql(sql)
    except Exception as e:
        return {
            "question": request.question,
            "sql": sql,
            "answer": f"Error executing query: {str(e)}",
            "status": "error",
            "source": "database",
            "sources": [],
            "columns": [],
            "rows": [],
        }

    try:
        answer = generate_answer(request.question, sql, columns, rows)
    except Exception as e:
        answer = f"Found {len(rows)} result(s), but could not generate a summary: {str(e)}"

    return {
        "question": request.question,
        "sql": sql,
        "answer": answer,
        "status": "ok",
        "source": "database",
        "sources": [],
        "columns": columns,
        "rows": rows,
    }
