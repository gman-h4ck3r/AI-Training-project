import os
import re
import requests

from fastapi import FastAPI
from pydantic import BaseModel
from databricks.sdk import WorkspaceClient
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------

CHAT_MODEL = os.environ.get("CHAT_MODEL", "databricks-llama-4-maverick")
WAREHOUSE_ID = os.environ.get("WAREHOUSE_ID", "4bddb0c7d84eee0b")

# ---------------------------------------------------------
# FastAPI
# ---------------------------------------------------------

app = FastAPI()

app.mount(
    "/static",
    StaticFiles(directory="static"),
    name="static",
)

# ---------------------------------------------------------
# Databricks client
# ---------------------------------------------------------

w = WorkspaceClient()

auth_headers = w.config.authenticate()
access_token = auth_headers["Authorization"].replace("Bearer ", "", 1)
workspace_host = w.config.host
serving_endpoint = workspace_host.rstrip("/") + "/serving-endpoints"

print(f"Workspace host: {workspace_host}")
print(f"Chat model: {CHAT_MODEL}")
print(f"Warehouse ID: {WAREHOUSE_ID}")

# ---------------------------------------------------------
# Database schema description
# ---------------------------------------------------------

SCHEMA_DESCRIPTION = """
DATABASE SCHEMA — workspace.project_db

Table: workspace.project_db.assets
  Columns: Asset_ID (string), Asset_Name (string), Asset_Type (string),
  Asset_Category (string), Description (string), Manufacturer (string),
  Model (string), Serial_Number (string), Asset_Tag (string),
  Hostname (string), IP_Address (string), MAC_Address (string),
  Site (string), Area (string), Unit (string), Cabinet (string),
  Rack (string), Zone (string), Purdue_Level (string),
  Security_Zone (string), Network_Segment (string), VLAN (bigint),
  Switch (string), Switch_Port (string), Owner (string),
  System_Owner (string), OT_Security_Owner (string), Vendor (string),
  Integrator (string), Criticality (string), Safety_Criticality (string),
  Business_Criticality (string), Operational_Criticality (string),
  OS (string), OS_Version (string), Firmware (string),
  Firmware_Version (string), Application (string),
  Application_Version (string), PLC_Runtime (string),
  Patch_Level (string), EOL_Status (string), Support_Status (string),
  OT_Protocols (string), Open_Ports (string), Communication_Partners (string),
  Remote_Access (string), Remote_Access_Method (string),
  Authentication (string), MFA (string), EDR_AV (string),
  Logging (string), SIEM (string), Network_Monitoring (string),
  Backup_Status (string), Last_Backup (string), Last_Restore_Test (string),
  Configuration_Backup (string), PLC_Logic_Version (string),
  Last_Configuration_Change (string), Last_Maintenance (string),
  Last_Security_Assessment (string), Last_Vulnerability_Assessment (string),
  CVE_Count (bigint), Highest_CVSS (double), Compensating_Controls (string),
  Risk_Rating (string), Risk_Assessment_Date (string), RTO (string),
  RPO (string), Commission_Date (string), EOL_Date (string),
  Replacement_Plan (string), Lifecycle_Status (string),
  Discovery_Source (string), First_Discovered (string),
  Last_Verified (string), Inventory_Confidence (string)

Table: workspace.project_db.network_interfaces
  Columns: Asset_ID (string, FK->assets.Asset_ID), Interface (string),
  IP_Address (string), MAC_Address (string), VLAN (bigint),
  Switch (string), Switch_Port (string), Subnet (string),
  Assignment (string), Security_Zone (string)

Table: workspace.project_db.communication_flows
  Columns: Source_Asset (string, FK->assets.Asset_ID),
  Destination_Asset (string, FK->assets.Asset_ID), Protocol (string),
  Port (string), Direction (string), Purpose (string),
  Business_Necessity (string)

Table: workspace.project_db.software_firmware
  Columns: Asset_ID (string, FK->assets.Asset_ID), Platform (string),
  Platform_Version (string), Software (string), Software_Version (string),
  Purpose (string)

Table: workspace.project_db.vulnerabilities
  Columns: Asset_ID (string, FK->assets.Asset_ID),
  Vulnerability_ID (string), Severity (string), CVSS (double),
  Status (string), Compensating_Control (string), Target_Date (string)

Table: workspace.project_db.relationships
  Columns: Source_Asset (string, FK->assets.Asset_ID),
  Target_Asset (string, FK->assets.Asset_ID), Relationship (string)

Table: workspace.project_db.readme
  Columns: Item (string), Value (string)

JOIN KEYS:
  network_interfaces.Asset_ID = assets.Asset_ID
  software_firmware.Asset_ID = assets.Asset_ID
  vulnerabilities.Asset_ID = assets.Asset_ID
  communication_flows.Source_Asset = assets.Asset_ID
  communication_flows.Destination_Asset = assets.Asset_ID
  relationships.Source_Asset = assets.Asset_ID
  relationships.Target_Asset = assets.Asset_ID
"""

SYSTEM_PROMPT = """You are an expert SQL assistant for an OT (Operational Technology) cybersecurity asset inventory database in Databricks Unity Catalog.

Your job: convert natural language questions into a single valid Databricks SQL query.

CRITICAL RULES:
1. Always use FULLY QUALIFIED table names: workspace.project_db.<table_name>
2. Return ONLY the SQL query — no markdown, no backticks, no explanation, no semicolons.
3. Asset_ID is the unique identifier for assets (e.g., 'PLC-001', 'SCADA-001', 'DCS-001', 'HMI-001').
   When a user says "asset PLC-001", filter on Asset_ID = 'PLC-001', NOT Asset_Name.
4. CVSS score is in the vulnerabilities table as column CVSS (double).
   Highest_CVSS in the assets table is the max CVSS per asset.
   When a user asks about "CVE risk score higher than 5", filter on v.CVSS > 5.
5. Use JOIN when the question spans multiple tables.
6. Select meaningful columns that answer the question — not SELECT *.
7. If the question cannot be answered from the available tables, return exactly: CANNOT_ANSWER

""" + SCHEMA_DESCRIPTION + """

EXAMPLE:
Question: "Give me all vulnerabilities for asset PLC-001 with a CVE risk score higher than 5"
SQL: SELECT a.Asset_ID, a.Asset_Name, v.Vulnerability_ID, v.Severity, v.CVSS, v.Status, v.Compensating_Control, v.Target_Date FROM workspace.project_db.assets a JOIN workspace.project_db.vulnerabilities v ON a.Asset_ID = v.Asset_ID WHERE a.Asset_ID = 'PLC-001' AND v.CVSS > 5
"""


ANSWER_SYSTEM_PROMPT = """You are the OT Asset Inventory Assistant, an expert in OT cybersecurity.
You are given a user's question, the SQL query that was generated, and the query results.
Your job is to provide a clear, concise natural language answer based on the data.

Rules:
1. Answer the user's question directly using the data from the query results.
2. If the results are empty, say so and explain what was searched for.
3. Be specific: mention asset names, IDs, counts, scores, etc. from the data.
4. If the user asks "how many", give the exact number.
5. If the user asks about the "highest" or "most", identify the specific item and its value.
6. Keep your answer concise but informative - 2-4 sentences typically.
7. Do not mention SQL or the query in your answer unless the user specifically asks about it.
"""


# ---------------------------------------------------------
# Text-to-SQL
# ---------------------------------------------------------

def generate_sql(question: str) -> str:
    resp = requests.post(
        f"{serving_endpoint}/{CHAT_MODEL}/invocations",
        headers={"Authorization": f"Bearer {access_token}"},
        json={
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Convert this question to SQL:\n{question}"},
            ],
            "max_tokens": 1000,
        },
        timeout=30,
    )
    resp.raise_for_status()
    sql = resp.json()["choices"][0]["message"]["content"].strip()

    # Clean up markdown if the LLM added it
    sql = re.sub(r"^```sql\s*", "", sql)
    sql = re.sub(r"^```\s*", "", sql)
    sql = re.sub(r"\s*```$", "", sql)
    sql = sql.strip().rstrip(";")

    return sql


# ---------------------------------------------------------
# Execute SQL
# ---------------------------------------------------------

def execute_sql(sql: str):
    result = w.statement_execution.execute_statement(
        warehouse_id=WAREHOUSE_ID,
        statement=sql,
        wait_timeout="50s",
    )

    columns = []
    rows = []

    state = result.status.state if result.status else "unknown"
    print(f"  SQL state: {state}")

    if result.manifest and result.manifest.schema:
        columns = [c.name for c in result.manifest.schema.columns]

    if result.result and result.result.data_array:
        for row in result.result.data_array:
            rows.append(list(row) if row else [])

    print(f"  Columns: {columns}")
    print(f"  Row count: {len(rows)}")
    if rows:
        print(f"  First row: {rows[0]}")

    return columns, rows


# ---------------------------------------------------------
# Generate natural language answer
# ---------------------------------------------------------

def generate_answer(question: str, sql: str, columns: list, rows: list) -> str:
    if not rows:
        data_str = "No rows returned (empty result set)."
    else:
        header = " | ".join(columns)
        separator = "-+-".join(["-" * len(c) for c in columns])
        data_lines = [header, separator]
        for row in rows[:50]:
            data_lines.append(" | ".join([str(v) if v is not None else "NULL" for v in row]))
        if len(rows) > 50:
            data_lines.append(f"... ({len(rows)} total rows, showing first 50)")
        data_str = "\n".join(data_lines)

    prompt = (
        f"User question: {question}\n\n"
        f"SQL query executed:\n{sql}\n\n"
        f"Query results ({len(rows)} rows):\n{data_str}\n\n"
        f"Please provide a natural language answer to the user's question based on these results."
    )

    resp = requests.post(
        f"{serving_endpoint}/{CHAT_MODEL}/invocations",
        headers={"Authorization": f"Bearer {access_token}"},
        json={
            "messages": [
                {"role": "system", "content": ANSWER_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "max_tokens": 1000,
        },
        timeout=30,
    )
    resp.raise_for_status()
    answer = resp.json()["choices"][0]["message"]["content"].strip()
    return answer


# ---------------------------------------------------------
# Request model
# ---------------------------------------------------------

class AskRequest(BaseModel):
    question: str


# ---------------------------------------------------------
# API endpoints
# ---------------------------------------------------------

@app.get("/")
def home():
    return FileResponse("static/index.html")


@app.post("/api/ask")
def ask(request: AskRequest):
    print(f"\n=== QUESTION: {request.question} ===")
    try:
        sql = generate_sql(request.question)
        print(f"  Generated SQL: {sql}")
    except Exception as e:
        print(f"  SQL generation error: {e}")
        return {
            "question": request.question,
            "sql": "",
            "answer": f"Failed to generate SQL: {str(e)}",
            "status": "error",
            "columns": [],
            "rows": [],
        }

    if sql == "CANNOT_ANSWER":
        return {
            "question": request.question,
            "sql": "",
            "answer": "I cannot answer this question from the available database tables.",
            "status": "error",
            "columns": [],
            "rows": [],
        }

    try:
        columns, rows = execute_sql(sql)
    except Exception as e:
        return {
            "question": request.question,
            "sql": sql,
            "answer": f"Error executing query: {str(e)}",
            "status": "error",
            "columns": [],
            "rows": [],
        }

    try:
        answer = generate_answer(request.question, sql, columns, rows)
    except Exception as e:
        answer = f"Found {len(rows)} result(s), but could not generate a summary: {str(e)}"

    return {
        "question": request.question,
        "sql": sql,
        "answer": answer,
        "status": "ok",
        "columns": columns,
        "rows": rows,
    }
