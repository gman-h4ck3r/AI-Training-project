document.addEventListener("DOMContentLoaded", () => {

    const chat = document.getElementById("chat");
    const form = document.getElementById("questionForm");
    const input = document.getElementById("questionInput");
    const sendButton = document.getElementById("sendButton");
    const sendText = document.getElementById("sendText");
    const clearButton = document.getElementById("clearButton");

    let welcome = document.getElementById("welcome");

    // ---------------------------------------------------------
    // Utility
    // ---------------------------------------------------------

    function escapeHtml(value) {
        const div = document.createElement("div");
        div.textContent = value ?? "";
        return div.innerHTML;
    }

    function scrollToBottom() {
        window.scrollTo({
            top: document.body.scrollHeight,
            behavior: "smooth"
        });
    }

    // ---------------------------------------------------------
    // Messages
    // ---------------------------------------------------------

    function addUserMessage(question) {
        const message = document.createElement("div");
        message.className = "message user";
        message.innerHTML = `
            <div class="message-avatar">YOU</div>
            <div class="message-content">
                <div class="message-role">You</div>
                <div class="message-text">${escapeHtml(question)}</div>
            </div>
        `;
        chat.appendChild(message);
        scrollToBottom();
    }

    function addAssistantMessage(answer, sql, columns, rows, status, source, sources) {
        const message = document.createElement("div");
        message.className = "message assistant";

        // Build source badge
        let sourceHtml = "";
        if (source === "documents" || source === "both") {
            let badges = (sources || []).map(s => `<span class="source-badge">${escapeHtml(s)}</span>`).join("");
            if (badges) {
                sourceHtml = `<div class="source-badges">From documents: ${badges}</div>`;
            }
        }

        // Build SQL block
        let sqlHtml = "";
        if (sql) {
            sqlHtml = `
                <div class="sql-label">Generated SQL</div>
                <div class="sql-block">${escapeHtml(sql)}</div>
            `;
        }

        // Build results table
        let tableHtml = "";
        if (columns && columns.length > 0 && rows && rows.length > 0) {
            let thead = columns.map(c => `<th>${escapeHtml(c)}</th>`).join("");
            let tbody = rows.map(row =>
                `<tr>${row.map(v => `<td>${escapeHtml(v ?? "NULL")}</td>`).join("")}</tr>`
            ).join("");
            tableHtml = `
                <div class="results-table-container">
                    <table class="results-table">
                        <thead><tr>${thead}</tr></thead>
                        <tbody>${tbody}</tbody>
                    </table>
                </div>
            `;
        } else if (sql && !answer.includes("Error")) {
            tableHtml = `<div class="results-empty">No rows returned.</div>`;
        }

        // Build error display
        let errorHtml = "";
        let isError = status === "error" || answer.includes("Error") || answer.includes("Failed");
        if (isError) {
            errorHtml = `<div class="error">${escapeHtml(answer)}</div>`;
        }

        message.innerHTML = `
            <div class="message-avatar">OT</div>
            <div class="message-content">
                <div class="message-role">OT Asset Inventory Assistant</div>
                ${errorHtml ? "" : `<div class="message-text">${escapeHtml(answer)}</div>`}
                ${errorHtml}
                ${sourceHtml}
                ${sqlHtml}
                ${tableHtml}
            </div>
        `;

        chat.appendChild(message);
        scrollToBottom();
    }

    function addLoadingMessage() {
        const message = document.createElement("div");
        message.id = "loadingMessage";
        message.className = "message assistant";
        message.innerHTML = `
            <div class="message-avatar">OT</div>
            <div class="message-content">
                <div class="message-role">OT Asset Inventory Assistant</div>
                <div class="loading">Thinking<span class="loading-dots">...</span></div>
            </div>
        `;
        chat.appendChild(message);
        scrollToBottom();
    }

    function removeLoadingMessage() {
        const loading = document.getElementById("loadingMessage");
        if (loading) {
            loading.remove();
        }
    }

    // ---------------------------------------------------------
    // API call
    // ---------------------------------------------------------

    async function askQuestion(question) {
        const response = await fetch("/api/ask", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ question: question })
        });

        if (!response.ok) {
            let message = `Request failed with HTTP ${response.status}`;
            try {
                const errorData = await response.json();
                if (errorData.detail) {
                    message = errorData.detail;
                }
            } catch { /* keep default */ }
            throw new Error(message);
        }

        return await response.json();
    }

    // ---------------------------------------------------------
    // Send question
    // ---------------------------------------------------------

    async function sendQuestion(question) {
        question = question.trim();
        if (!question) return;

        if (welcome) {
            welcome.remove();
            welcome = null;
        }

        addUserMessage(question);
        input.value = "";
        input.disabled = true;
        sendButton.disabled = true;
        sendText.textContent = "Thinking";

        addLoadingMessage();

        try {
            const data = await askQuestion(question);
            removeLoadingMessage();
            addAssistantMessage(
                data.answer || "No answer was returned.",
                data.sql || "",
                data.columns || [],
                data.rows || [],
                data.status || "ok",
                data.source || "",
                data.sources || []
            );
        } catch (error) {
            removeLoadingMessage();
            addAssistantMessage(
                error.message || "Unable to contact the assistant.",
                "",
                [],
                [],
                "error",
                "",
                []
            );
        } finally {
            input.disabled = false;
            sendButton.disabled = false;
            sendText.textContent = "Send";
            input.focus();
        }
    }

    // ---------------------------------------------------------
    // Form submit
    // ---------------------------------------------------------

    form.addEventListener("submit", (event) => {
        event.preventDefault();
        sendQuestion(input.value);
    });

    // ---------------------------------------------------------
    // Enter / Shift+Enter
    // ---------------------------------------------------------

    input.addEventListener("keydown", (event) => {
        if (event.key === "Enter" && !event.shiftKey) {
            event.preventDefault();
            form.dispatchEvent(new Event("submit", {
                bubbles: true,
                cancelable: true
            }));
        }
    });

    // ---------------------------------------------------------
    // Suggestion buttons
    // ---------------------------------------------------------

    function attachSuggestionHandlers() {
        document
            .querySelectorAll(".suggestion")
            .forEach(button => {
                button.addEventListener("click", () => {
                    sendQuestion(button.dataset.question);
                });
            });
    }

    attachSuggestionHandlers();

    // ---------------------------------------------------------
    // Clear conversation
    // ---------------------------------------------------------

    clearButton.addEventListener("click", () => {
        chat.innerHTML = `
            <div class="welcome" id="welcome">
                <div class="welcome-icon">OT</div>
                <h2>How can I help?</h2>
                <p>
                    Ask questions about the OT asset inventory — assets, vulnerabilities,
                    network interfaces, communication flows, software, and relationships.
                    You can also ask about OT asset management procedures and policies from
                    the reference documents.
                </p>
                <div class="suggestions">
                    <button
                        class="suggestion"
                        data-question="Give me all vulnerabilities for asset SCADA-001 with a CVE risk score higher than 5"
                    >
                        Give me all vulnerabilities for asset SCADA-001 with a CVE risk score higher than 5
                    </button>
                    <button
                        class="suggestion"
                        data-question="What is the procedure for registering a new OT asset?"
                    >
                        What is the procedure for registering a new OT asset?
                    </button>
                    <button
                        class="suggestion"
                        data-question="How should network interfaces be configured for OT assets?"
                    >
                        How should network interfaces be configured for OT assets?
                    </button>
                </div>
            </div>
        `;

        welcome = document.getElementById("welcome");
        attachSuggestionHandlers();
        input.value = "";
        input.focus();
    });

    console.log("OT Asset Inventory Assistant frontend initialized");
});
